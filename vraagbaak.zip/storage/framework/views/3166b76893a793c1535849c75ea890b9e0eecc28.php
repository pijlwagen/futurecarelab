<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <form action="<?php echo e(route('question.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group text-center">
                        <h2>Stel uw vraag!</h2>
                        <p>Typ uw vraag in het tekst veld hier beneneden en klik op de paarse knop.</p>
                    </div>
                    <div class="form-group">
                        <textarea name="question" id="question" cols="30" rows="10"
                                  class="form-control<?php echo e($errors->has('question') ? ' is-invalid' : ''); ?>"><?php echo e(old('question')); ?></textarea>
                        <?php if($errors->has('question')): ?>
                            <div class="invalid-feedback">
                                <?php echo $errors->get('question')[0]; ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="category">Mijn vraag behoord in de categorie</label>
                        <select name="category" id="category" class="form-control <?php if ($errors->has('category')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('category'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($category === old('$category')): ?>
                                    <option value="<?php echo e($category->id); ?>" selected><?php echo e($category->name); ?></option>
                                <?php else: ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if ($errors->has('category')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('category'); ?>
                        <span class="invalid-feedback">
                                <?php echo e($message); ?>

                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="email">Mijn email adres is</label>
                        <input type="text" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="email"
                               name="email" placeholder="naam@voorbeeld.nl" value="<?php echo e(old('email')); ?>">
                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                        <span class="invalid-feedback">
                                <?php echo e($message); ?>

                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                    <div class="form-group">
                        <button class="btn btn-primary float-right">Vraag stellen</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vraagbaak\resources\views/home.blade.php ENDPATH**/ ?>