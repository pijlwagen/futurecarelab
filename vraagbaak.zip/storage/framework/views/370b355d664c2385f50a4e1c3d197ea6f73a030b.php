<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="">
            <p>Typ uw email adres om uw vragen te zien</p>
            <div class="form-group row">
                <div class="col-md-9 mb-3">
                    <input type="email" name="email" id="email" placeholder="voorbeeld@domein.nl" class="form-control" value="<?php echo e($email); ?>">
                </div>
                <div class="col-md-3">
                    <button class="btn btn-primary w-100">Zoeken</button>
                </div>
            </div>
        </form>
        <hr>
        <table class="table table-responsive-md w-100">
            <tr>
                <th>Vraag nummer</th>
                <th>Categorie</th>
                <th>Status</th>
                <th>Geplaatst op</th>
                <th>Acties</th>
            </tr>
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($question->id); ?></td>
                    <td><?php echo e($question->getCategory()->name ?? 'Cat. is verwijderd'); ?></td>
                    <td><?php echo e($question->getTag()->name); ?></td>
                    <td><?php echo e($question->created_at); ?></td>
                    <td><a href="<?php echo e(route('question.view', ['id' => $question->id])); ?>">Bekijken</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vraagbaak\resources\views/questions/my-questions.blade.php ENDPATH**/ ?>