<?php $__env->startSection('content'); ?>
    <div class="container">
        <table class="table table-responsive-md table-striped">
            <tr>
                <th>ID</th>
                <th>E-Mail</th>
                <th>Geverifieerd</th>
                <th>Geblokkeerd</th>
                <th>Acties</th>
            </tr>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($user->id); ?></th>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo $user->verified ? '<i class="fas fa-check text-success"></i>' : '<i class="fas fa-times text-danger"></i>'; ?></td>
                    <td><?php echo $user->isBlocked() ? '<i class="fas fa-check text-success"></i>' : '<i class="fas fa-times text-danger"></i>'; ?></td>
                    <td>
                        <?php if(!$user->verified): ?>
                            <a href="<?php echo e(route('admin.user.verify', ['id' => $user->id])); ?>" class="text-primary mr-2">Verifiëren</a>
                        <?php endif; ?>
                        <?php if($user->isBlocked()): ?>
                            <a href="<?php echo e(route('admin.user.block', ['id' => $user->id])); ?>" class="text-warning mr-2">De-blokkeren</a>
                        <?php else: ?>
                            <a href="<?php echo e(route('admin.user.block', ['id' => $user->id])); ?>" class="text-danger mr-2">Blokkeren</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <?php echo e($users->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vraagbaak\resources\views/admin/users.blade.php ENDPATH**/ ?>