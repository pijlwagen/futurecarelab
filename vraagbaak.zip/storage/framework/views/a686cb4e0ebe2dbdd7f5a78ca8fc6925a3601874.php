<?php $__env->startSection('content'); ?>
    <?php
        $tag = $question->getTag();
        $category = $question->getCategory();
        $i = 0;
        $date = \Carbon\Carbon::parse($question->created_at)->setTimezone('Europe/Amsterdam');
    ?>
    <div class="container px-5 justify-content-center">
        <div class="row mb-2">
            <div class="col">
                <?php if(Auth::check()): ?>
                    <?php if(Auth::user()->isAdmin()): ?>
                        <form action="<?php echo e(route('question.delete')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="id" readonly hidden value="<?php echo e($question->id); ?>">
                            <button onclick="return confirm('Weet u zeker dat u deze vraag wilt verwijderen?')"
                                    class="ml-3 btn btn-danger float-right">Vraag verwijderen
                            </button>
                        </form>
                    <?php endif; ?>
                    <?php if($question->isOpen()): ?>
                        <a class="ml-3 btn btn-info float-right" href="#" data-toggle="modal"
                           data-target="#close-modal">
                            Vraag sluiten
                        </a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="card mb-5 shadow-sm">
            <div class="card-header">
                <h5>
                    <?php if($tag): ?>
                        <span class="badge float-right"
                              style="background-color: <?php echo e($tag->hex); ?>;color:#fff;"><?php echo e($tag->name); ?></span>
                    <?php endif; ?>
                    <?php if($category): ?>
                        <span class="badge float-right mr-2"
                              style="background-color: <?php echo e($category->hex ?? '#cecece'); ?>;color:#fff;"><?php echo e($category->name); ?></span>
                    <?php endif; ?>
                </h5>
                <h3 class="float-left float-md-none">Vraag #<?php echo e($question->id); ?></h3>

            </div>
            <div class="card-body">
                <?php echo $question->content; ?>

            </div>
            <div class="card-footer">
                <p class="text-right text-muted font-italic float-right">
                    Geplaatst: <?php echo e($date->isToday() ? 'vandaag om ' . $date->isoFormat('H:mm') : $date->isoFormat('lll')); ?>

                </p>
                <?php if($question->isOpen() && Auth::check()): ?>
                    <a class="btn btn-primary mr-2" data-toggle="collapse" href="#answer-question" role="button"
                       aria-expanded="false" aria-controls="answer-question">Beantwoorden</a>
                    <div class="collapse" id="answer-question">
                        <div class="mt-3">
                            <form action="<?php echo e(route('answer.store', ['question' => $question->id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="answer">Antwoord:</label>
                                    <textarea name="content" id="answer" cols="30" rows="10"
                                              class="form-control<?php echo e($errors->has('content') ? ' is-invalid' : ''); ?>"></textarea>
                                    <?php if($errors->has('content')): ?>
                                        <div class="invalid-feedback">
                                            <?php echo $errors->get('content')[0]; ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <button class="btn btn-outline-success">Plaatsen</button>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php $__currentLoopData = $question->getAnswers(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $date = \Carbon\Carbon::parse($answer->created_at)->setTimezone('Europe/Amsterdam');
                $i++;
            ?>
            <div class="card mb-2 shadow-sm">
                <div class="card-header">
                    <?php if(Auth::check() && Auth::user()->isAdmin()): ?>
                        <form action="<?php echo e(route('answer.delete')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="id" readonly hidden value="<?php echo e($answer->id); ?>">
                            <button onclick="return confirm('Weet u zeker dat u dit antwoord wilt verwijderen?')"
                                    class="ml-3 btn btn-danger float-right">Antwoord verwijderen
                            </button>
                        </form>
                    <?php endif; ?>
                    <h4>Antwoord #<?php echo e($i); ?></h4>
                </div>
                <div class="card-body">
                    <?php echo e($answer->content); ?>

                </div>
                <div class="card-footer">
                    <p class="text-right text-muted font-italic float-right">
                        Geplaatst: <?php echo e($date->isToday() ? 'vandaag om ' . $date->isoFormat('H:mm') : $date->isoFormat('lll')); ?>

                    </p>
                    <p>Geplaatst door: <?php echo e($answer->getAuthor()->name); ?></p>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php if(Auth::check()): ?>
        <div class="modal fade" id="close-modal" tabindex="-1" role="dialog" aria-labelledby="close-modal"
             aria-hidden="true">
            <div class="modal-dialog" role="document">
                <form action="<?php echo e(route('question.close', ['id' => $question->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="answered"> Hoe wilt u deze vraag markeren?</label>
                                <select name="answered" id="answered" class="form-control">
                                    <option value="1">Beantwoord</option>
                                    <option value="0">Gesloten</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-info">Opslaan</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vraagbaak\resources\views/questions/view.blade.php ENDPATH**/ ?>