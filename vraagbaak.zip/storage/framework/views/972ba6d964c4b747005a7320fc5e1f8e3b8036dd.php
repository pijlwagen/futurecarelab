<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card card-body">
            <form action="" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name">Naam</label>
                    <input type="text" class="form-control" name="name" id="name" value="<?php echo e($category->name); ?>">
                </div>
                <div class="form-group">
                    <label for="color">Kleur</label>
                    <input type="color" class="form-control" name="color" id="color" value="<?php echo e($category->hex); ?>">
                </div>
                <a href="javascript:history.back();" class="btn btn-primary">Terug</a>
                <button class="btn btn-primary float-right">Opslaan</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vraagbaak\resources\views/admin/category/edit.blade.php ENDPATH**/ ?>