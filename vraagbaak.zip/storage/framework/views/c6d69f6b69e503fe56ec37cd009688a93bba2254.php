<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="card">

                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header text-center">
                        <h5>Mijn account</h5>
                    </div>
                    <div class="card-body">
                        <p><strong>Rol:</strong> <?php echo e(ucfirst(Auth::user()->getRole()->name)); ?></p>
                        <p><strong>ID:</strong> <?php echo e(Auth::user()->id); ?></p>
                        <p><strong>E-Mail:</strong> <?php echo e(Auth::user()->email); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vraagbaak\resources\views/admin/index.blade.php ENDPATH**/ ?>