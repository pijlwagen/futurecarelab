<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="">
            <div class="form-group row">
                <div class="col-md-8 mb-3">
                    <select name="categorie" class="form-control" required>
                        <option disabled selected>Selecteer een categorie</option>
                        <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($cat->name === Request::query('categorie')): ?>
                                <option value="<?php echo e($cat->name); ?>" selected><?php echo e($cat->name); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($cat->name); ?>"><?php echo e($cat->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-2 mb-3">
                    <button class="btn btn-primary w-100">Filteren</button>
                </div>
                <div class="col-md-2 mb-3">
                    <a href="<?php echo e(route('question')); ?>" class="btn btn-primary w-100">Reset</a>
                </div>
            </div>
        </form>
        <div class="row">
            <div class="col-md-8 mb-3">
                <div class="card">
                    <div class="card-header">
                        <strong>Open vragen</strong>
                    </div>
                    <div class="card-body">
                        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('question.view', ['id' => $question->id])); ?>">Vraag
                                #<?php echo e($question->id); ?></a><br>
                            <small
                                class="text-muted font-italic"><?php echo e(\Illuminate\Support\Str::limit($question->content, 30)); ?></small>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($questions->links()); ?>

                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <strong>Recente vragen</strong>
                    </div>
                    <div class="card-body">
                        <?php $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php ($tag = $item->getTag()); ?>
                            <?php ($category = $item->getCategory()); ?>
                            <a href="<?php echo e(route('question.view', ['id' => $item->id])); ?>">Vraag #<?php echo e($item->id); ?> <?php if($tag): ?>
                                    <span
                                        class="badge float-right"
                                        style="background-color: <?php echo e($tag->hex); ?>;color:#fff;"><?php echo e($tag->name); ?></span>
                                <?php endif; ?>
                                <?php if($category): ?>
                                    <span
                                        class="badge float-right mr-2"
                                        style="background-color: <?php echo e($category->hex ?? '#cecece'); ?>;color:#fff;"><?php echo e($category->name); ?></span>
                                <?php endif; ?>
                            </a>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vraagbaak\resources\views/questions/index.blade.php ENDPATH**/ ?>