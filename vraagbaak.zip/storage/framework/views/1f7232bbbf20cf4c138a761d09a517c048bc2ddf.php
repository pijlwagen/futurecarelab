<?php $__env->startSection('content'); ?>
    <div class="container">
        <a href="<?php echo e(route('admin.cat.create')); ?>" class="btn btn-primary float-right mb-3">Categorie Toevoegen</a>
        <table class="table table-responsive-md table-striped">
            <tr>
                <th>ID</th>
                <th>Naam</th>
                <th>Kleur code</th>
                <th>Acties</th>
            </tr>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($category->id); ?></th>
                    <td><?php echo e($category->name); ?></td>
                    <td><pre style="color: <?php echo e($category->hex); ?>; background: #222; padding: 5px; border-radius: 5px;"><?php echo e($category->hex); ?></pre></td>
                    <td><a href="<?php echo e(route('admin.cat.edit', ['id' => $category->id])); ?>" class="text-warning mr-2">Aanpassen</a> <a href="<?php echo e(route('admin.cat.delete', ['id' => $category->id])); ?>" class="text-danger mr-2">Verwijderen</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <?php echo e($categories->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\vraagbaak\resources\views/admin/category/index.blade.php ENDPATH**/ ?>