@extends('layouts.app')

@section('content')

    <div class="container">
        <div class="section">
            <div class="row mb-5 justify-content-center">

                <div class="col-md-7 text-center bg-secondary ">
                    Collum one
                    <br><br><br><br><br><br><br>
                </div>

            </div>   <!-- end row  -->


            <div class="row mb-5 justify-content-center">
                <div class="col-md-5 text-center bg-secondary mr-5">
                    Left Side Col Row 2
                    <br><br><br><br><br><br><br>
                </div>

                <div class="col-md-5 text-center bg-secondary ml-5">
                    Right Side Col Row 2
                    <br><br><br><br><br><br><br>
                </div>

            </div> <!-- row end -->

            <div class="row mb-5 justify-content-center">

                <div class="col-md-5 text-center bg-secondary mr-5">
                    Left Side Col Row 2
                    <br><br><br><br><br><br><br>
                </div>

                <div class="col-md-5 text-center bg-secondary ml-5">
                    Right Side Col Row 2
                    <br><br><br><br><br><br><br>
                </div>


            </div> <!-- row end -->
        </div>  <!-- end section -->
    </div> <!-- end container -->

@endsection