<?php

return [

    'password' => 'Het wachtwoord moet minstens 8 karakters lang zijn en het zelfde zijn als de herhaling.',
    'reset' => 'Uw wachtwoord is opnieuw ingesteld.',
    'sent' => 'We have e-mailed your password reset link!',
    'token' => 'This password reset token is invalid.',
    'user' => "Er is geen gebruiker met dit e-mail adres.",

];
