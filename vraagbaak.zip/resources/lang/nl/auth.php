<?php

return [

    'failed' => 'Deze gegevens komen niet voor in ons systeem.',
    'throttle' => 'U heeft te vaak proberen in te loggen, probeer het opnieuw in :seconds seconde(s).',

];
